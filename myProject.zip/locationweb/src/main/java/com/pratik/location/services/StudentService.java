package com.pratik.location.services;

import com.pratik.location.entities.Student;

public interface StudentService {
	
	Student addStudent(Student student);

}
