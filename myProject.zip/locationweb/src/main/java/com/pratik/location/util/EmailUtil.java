package com.pratik.location.util;

public interface EmailUtil {

	void sendEmail(String toAddress, String subject, String body);
}
